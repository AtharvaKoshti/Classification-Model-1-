import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.svm import SVC
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Sample DataFrame (replace this with your actual data)
data = pd.DataFrame({
    'Loan_ID': ['LP001', 'LP002', 'LP003', 'LP004', 'LP005'],
    'Gender': ['Male', 'Female', 'Male', 'Female', 'Male'],
    'Married': ['Yes', 'No', 'Yes', 'No', 'Yes'],
    'Dependents': [1, 0, 2, 0, 1],
    'Education': ['Graduate', 'Graduate', 'Graduate', 'Not Graduate', 'Graduate'],
    'Self_Employed': ['No', 'No', 'Yes', 'Yes', 'No'],
    'ApplicantIncome': [5000, 3000, 7000, 2000, 4000],
    'CoapplicantIncome': [2000, 1500, 3000, 0, 1000],
    'LoanAmount': [300, 200, 500, 150, 350],
    'Loan_Amount_Term': [360, 360, 360, 360, 360],
    'Credit_History': [1, 1, 1, 0, 1],
    'Property_Area': ['Urban', 'Rural', 'Semiurban', 'Urban', 'Rural'],
    'Loan_Status': ['Y', 'N', 'Y', 'Y', 'N']
})

# Drop Loan_ID and Loan_Status columns from X
X = data.drop(columns=['Loan_ID', 'Loan_Status'])

# Target variable
Y = data['Loan_Status']

# Train-test split with stratification
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.1, stratify=Y, random_state=2)

# Column Transformer for encoding categorical variables
categorical_features = ['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area']
categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features)
])

# SVM Classifier with linear kernel
classifier = Pipeline(steps=[('preprocessor', preprocessor),
                             ('classifier', SVC(kernel='linear'))])

# Fit SVM classifier to the training data
classifier.fit(X_train, Y_train)

# Streamlit App
st.title('Loan Approval Prediction App')

# Input fields for user to enter data
st.header('Enter Applicant Details:')
gender = st.selectbox('Gender', ['Male', 'Female'])
married = st.selectbox('Marital Status', ['Yes', 'No'])
dependents = st.slider('Dependents', 0, 3, 0)
education = st.selectbox('Education', ['Graduate', 'Not Graduate'])
self_employed = st.selectbox('Self Employed', ['Yes', 'No'])
applicant_income = st.number_input('Applicant Income')
coapplicant_income = st.number_input('Coapplicant Income')
loan_amount = st.number_input('Loan Amount')
loan_amount_term = st.number_input('Loan Amount Term')
credit_history = st.selectbox('Credit History', [0, 1])
property_area = st.selectbox('Property Area', ['Urban', 'Rural', 'Semiurban'])

# Prepare input data as a DataFrame
input_data = pd.DataFrame({
    'Gender': [gender],
    'Married': [married],
    'Dependents': [dependents],
    'Education': [education],
    'Self_Employed': [self_employed],
    'ApplicantIncome': [applicant_income],
    'CoapplicantIncome': [coapplicant_income],
    'LoanAmount': [loan_amount],
    'Loan_Amount_Term': [loan_amount_term],
    'Credit_History': [credit_history],
    'Property_Area': [property_area]
})

# Predicting loan status
if st.button('Predict Loan Status'):
    prediction = classifier.predict(input_data)
    if prediction[0] == 'N':
        st.error('Loan Not Approved')
    else:
        st.success('Loan Approved')
