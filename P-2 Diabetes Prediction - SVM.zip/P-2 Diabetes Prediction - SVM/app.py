import streamlit as st
import joblib
import numpy as np
from PIL import Image

# Load the model and scaler
classifier = joblib.load('diabetes_classifier.joblib')
scaler = joblib.load('scaler.joblib')

# Set page configuration
st.set_page_config(page_title="Diabetes Prediction App", page_icon=":hospital:", layout="centered")

# Sidebar content
with st.sidebar:
    st.header("Diabetes Prediction App")
    st.markdown("""
    This app predicts if a person is diabetic based on input parameters.
    Please enter the following details and click on 'Predict' to see the result.
    """)

# Header content
st.header("Diabetes Prediction App")


# Input fields
st.subheader("Input Patient Data")

pregnancies = st.number_input("Pregnancies", min_value=0, max_value=20, value=0, step=1)
glucose = st.number_input("Glucose Level", min_value=0, max_value=200, value=120, step=1)
blood_pressure = st.number_input("Blood Pressure", min_value=0, max_value=150, value=70, step=1)
skin_thickness = st.number_input("Skin Thickness", min_value=0, max_value=100, value=20, step=1)
insulin = st.number_input("Insulin Level", min_value=0, max_value=900, value=79, step=1)
bmi = st.number_input("BMI", min_value=0.0, max_value=70.0, value=20.0, step=0.1)
diabetes_pedigree = st.number_input("Diabetes Pedigree Function", min_value=0.0, max_value=2.5, value=0.5, step=0.01)
age = st.number_input("Age", min_value=0, max_value=120, value=25, step=1)

# Button for prediction
if st.button('Predict'):
    input_data = (pregnancies, glucose, blood_pressure, skin_thickness, insulin, bmi, diabetes_pedigree, age)
    input_data_as_numpy_array = np.asarray(input_data).reshape(1, -1)

    # Standardize input data
    std_data = scaler.transform(input_data_as_numpy_array)

    # Make prediction
    prediction = classifier.predict(std_data)

    # Display result
    if prediction[0] == 0:
        st.success("The person is not diabetic.")
    else:
        st.error("The person is diabetic.")

# Footer
st.markdown("""
<hr style="height:2px;border:none;color:#333;background-color:#333;" />
<p style="text-align:center;">Built with ❤️ by Atharva Koshti </p>
""", unsafe_allow_html=True)
