import pandas as pd
import re
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# Ensure stopwords are downloaded
import nltk
nltk.download('stopwords')

# Define the stemming function
def stemming(content):
    porter_stemmer = PorterStemmer()
    stemmed_content = re.sub(r'[^a-zA-Z\s]', '', content)
    stemmed_content = stemmed_content.lower()
    stemmed_content = stemmed_content.split()
    stemmed_content = [porter_stemmer.stem(word) for word in stemmed_content if word not in stopwords.words('english')]
    return ' '.join(stemmed_content)

# Sample data
data = pd.DataFrame({
    'content': [
        "This is a real news article about technology advances.",
        "This is a fake news article spreading misinformation.",
        "Another real news article on scientific discovery.",
        "False claims about health benefits are misleading.",
        "Genuine report on economic growth.",
        "Misinformation on climate change trends."
    ],
    'label': [0, 1, 0, 1, 0, 1]  # 0 for real, 1 for fake
})

# Apply stemming
data['content'] = data['content'].apply(stemming)

# Convert text to TF-IDF features
tfidf_vectorizer = TfidfVectorizer()
X = tfidf_vectorizer.fit_transform(data['content'])
y = data['label']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = LogisticRegression()
model.fit(X_train, y_train)

# Save the model and vectorizer for later use
import joblib
joblib.dump(model, 'news_model.pkl')
joblib.dump(tfidf_vectorizer, 'vectorizer.pkl')


import streamlit as st
import joblib
import re
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import nltk

# Ensure stopwords are downloaded
nltk.download('stopwords')

# Load the model and vectorizer
model = joblib.load('news_model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

# Define the stemming function
def stemming(content):
    porter_stemmer = PorterStemmer()
    stemmed_content = re.sub(r'[^a-zA-Z\s]', '', content)
    stemmed_content = stemmed_content.lower()
    stemmed_content = stemmed_content.split()
    stemmed_content = [porter_stemmer.stem(word) for word in stemmed_content if word not in stopwords.words('english')]
    return ' '.join(stemmed_content)

# Streamlit app
st.title("Fake News Detector")

# User input
news_content = st.text_area("Enter news content:", height=200)

# Process and predict
if st.button("Predict"):
    if news_content.strip() != "":
        processed_content = stemming(news_content)
        transformed_content = vectorizer.transform([processed_content])
        prediction = model.predict(transformed_content)

        if prediction[0] == 0:
            st.success("The news is REAL")
        else:
            st.error("The news is FAKE")
    else:
        st.warning("Please enter some news content to predict.")
