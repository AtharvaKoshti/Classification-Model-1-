import streamlit as st
import numpy as np
import joblib
from sklearn.linear_model import LogisticRegression

# Load your model here (replace with the actual path to your model)
model_path = 'logistic_model.joblib'

# Set up the Streamlit app
st.set_page_config(
    page_title="Rock or Metal Classifier",
    page_icon="🎸",
    layout="centered",
    initial_sidebar_state="expanded",
)

def predict_with_model(model, input_data):
    """
    Predict the class using the provided model and input data.

    Parameters:
    - model: Trained machine learning model.
    - input_data: Tuple of feature values.

    Returns:
    - Predicted class: 'rock' or 'metal'.
    """
    try:
        input_data_as_numpy_array = np.asarray(input_data)
        expected_num_features = 60  # Adjust based on your model

        if input_data_as_numpy_array.shape[0] != expected_num_features:
            raise ValueError(f"Expected {expected_num_features} features, got {input_data_as_numpy_array.shape[0]}.")

        input_data_reshape = input_data_as_numpy_array.reshape(1, -1)
        prediction = model.predict(input_data_reshape)
        class_index = np.argmax(prediction)
        classes = ['rock', 'metal']

        return classes[class_index]
    except Exception as e:
        raise RuntimeError(f"An error occurred during prediction: {e}")

# Sidebar with instructions
st.sidebar.title("Instructions")
st.sidebar.info(
    """
    1. Enter the feature values in the provided text area.
    2. Click the 'Predict' button to classify the data.
    3. The prediction will be displayed below the button.
    """
)

# Main app layout
st.title("🎸 Rock or Metal Classifier")
st.markdown(
    """
    ### Welcome to the Rock or Metal Classifier!
    Provide the features of a music track and find out if it's **Rock** or **Metal**.
    """
)


# Input section
st.subheader("Enter Your Data")
input_data_str = st.text_area('Input Data (comma-separated)', value='0.0519,0.0548,...', height=200)

if st.button('Predict', help="Click to predict the class of the music track."):
    try:
        input_data_list = [float(x.strip()) for x in input_data_str.split(',')]
        
        if 'model' not in st.session_state:
            st.session_state.model = joblib.load(model_path)

        prediction = predict_with_model(st.session_state.model, input_data_list)
        
        st.success(f'🎉 Prediction: **{prediction}** 🎸')
    except ValueError as ve:
        st.error(f'Error: {ve}')
    except Exception as e:
        st.error(f'Error occurred during prediction: {e}')

# Additional styles and info
st.markdown(
    """
    **Note:** Ensure that you enter exactly 60 comma-separated values for a correct prediction.
    """
)

st.info(
    """
    🔍 For best results, use properly preprocessed and normalized data that matches the training data used for the model.
    """
)

# Footer
st.markdown("---")
st.markdown(
    """
    Developed with ❤️ using [Streamlit](https://streamlit.io).
    """
)

# CSS for further customization (Optional)
st.markdown(
    """
    <style>
    .css-18e3th9 {
        padding-top: 1rem;
        padding-bottom: 10rem;
        padding-left: 5rem;
        padding-right: 5rem;
    }
    .stButton>button {
        color: white;
        background: #ff4b4b;
    }
    .stSuccess, .stError {
        font-size: 1.2rem;
        font-weight: bold;
    }
    </style>
    """,
    unsafe_allow_html=True
)
